import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Plane } from 'lucide-react';

const Navbar = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path ? 'text-blue-600' : 'text-gray-600 hover:text-blue-600';
  };

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Plane className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">BritishAirwaysNumber</span>
            </Link>
          </div>
          <div className="hidden sm:flex sm:items-center sm:space-x-8">
            <Link to="/" className={`${isActive('/')} transition-colors duration-200 font-medium`}>
              Home
            </Link>
            <Link to="/support" className={`${isActive('/support')} transition-colors duration-200 font-medium`}>
              Support Numbers
            </Link>
            <Link to="/faq" className={`${isActive('/faq')} transition-colors duration-200 font-medium`}>
              FAQ
            </Link>
            <Link to="/disclaimer" className={`${isActive('/disclaimer')} transition-colors duration-200 font-medium`}>
              Disclaimer
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;