import React from 'react';
import { AlertTriangle } from 'lucide-react';

const Disclaimer = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex items-center justify-center mb-8">
          <AlertTriangle className="h-12 w-12 text-yellow-500" />
        </div>
        
        <h1 className="text-3xl font-bold text-center text-gray-900 mb-8">Legal Disclaimer</h1>
        
        <div className="space-y-6 text-gray-700">
          <p>
            BritishAirwaysNumber is an independent website that provides information about British Airways contact numbers and customer service details. We want to make it clear that:
          </p>
          
          <ul className="list-disc pl-6 space-y-4">
            <li>
              We are <span className="font-semibold">not affiliated</span> with British Airways plc or any of its subsidiaries.
            </li>
            <li>
              This website is maintained by independent contributors who aim to provide helpful information to travelers.
            </li>
            <li>
              While we strive to keep all information up-to-date and accurate, we cannot guarantee the accuracy of all phone numbers and contact details.
            </li>
            <li>
              The British Airways name, logo, and trademarks are property of British Airways plc and are used here for informational purposes only.
            </li>
          </ul>
          
          <div className="bg-blue-50 p-6 rounded-lg mt-8">
            <h2 className="text-xl font-semibold mb-4">Important Notice</h2>
            <p>
              For the most up-to-date and official contact information, we recommend visiting the official British Airways website at{' '}
              <a 
                href="https://www.britishairways.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-800"
              >
                www.britishairways.com
              </a>
            </p>
          </div>
          
          <div className="mt-8 text-sm text-gray-600">
            <p>
              Last updated: {new Date().toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Disclaimer;