import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Clock, Globe } from 'lucide-react';

const Home = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
          British Airways Contact Information
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Find the right contact numbers and support information for British Airways customer service worldwide.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <Phone className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">24/7 Support</h2>
          <p className="text-gray-600">Access to customer service representatives around the clock</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <Clock className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Quick Response</h2>
          <p className="text-gray-600">Get help with bookings, changes, and travel updates</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <Globe className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Global Coverage</h2>
          <p className="text-gray-600">International support numbers for travelers worldwide</p>
        </div>
      </div>

      <div className="text-center">
        <Link
          to="/support"
          className="inline-block bg-blue-600 text-white px-8 py-3 rounded-md font-semibold hover:bg-blue-700 transition-colors duration-200"
        >
          View Support Numbers
        </Link>
      </div>

      <div className="mt-16 bg-gray-100 rounded-lg p-8">
        <h2 className="text-2xl font-bold text-center mb-6">Why Choose Our Service?</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-2">Updated Information</h3>
            <p className="text-gray-600">We regularly verify and update our contact information to ensure accuracy.</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Easy Navigation</h3>
            <p className="text-gray-600">Find the right support number quickly with our organized directory.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;