import React from 'react';
import { HelpCircle } from 'lucide-react';

const faqs = [
  {
    question: "How do I reach British Airways from the US?",
    answer: "You can reach British Airways from the US by calling their toll-free number: +1 800 247 9297. This number is available 24/7 for all your travel needs."
  },
  {
    question: "What are the best times to call British Airways?",
    answer: "British Airways customer service is available 24/7, but call volumes are typically lower during off-peak hours (evening in your local time zone)."
  },
  {
    question: "Can I contact British Airways through social media?",
    answer: "Yes, British Airways responds to queries on Twitter (@British_Airways) and Facebook. However, for urgent matters, it's recommended to call their customer service directly."
  },
  {
    question: "What information should I have ready when I call?",
    answer: "Have your booking reference, flight details, and Executive Club number (if applicable) ready when you call. This will help expedite your service."
  },
  {
    question: "Are there different numbers for different services?",
    answer: "Yes, British Airways has dedicated numbers for services like booking, Executive Club membership, and lost baggage. Check our Support Numbers page for specific contact information."
  }
];

const FAQ = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h1>
        <p className="text-xl text-gray-600">Find answers to common questions about contacting British Airways</p>
      </div>

      <div className="space-y-6">
        {faqs.map((faq, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start">
              <HelpCircle className="h-6 w-6 text-blue-600 mr-4 mt-1" />
              <div>
                <h2 className="text-xl font-semibold text-gray-900">{faq.question}</h2>
                <p className="mt-2 text-gray-600">{faq.answer}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-blue-50 rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Still Need Help?</h2>
        <p className="text-gray-700">
          If you couldn't find the answer to your question, please visit our Support Numbers page to find the appropriate contact number for your region.
        </p>
      </div>
    </div>
  );
};

export default FAQ;