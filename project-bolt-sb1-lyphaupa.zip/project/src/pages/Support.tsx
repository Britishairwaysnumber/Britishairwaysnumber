import React from 'react';
import { Phone } from 'lucide-react';

const supportNumbers = [
  {
    country: 'United Kingdom',
    number: '+44 (0)20 8738 5050',
    hours: '24/7',
    notes: 'Main customer service line'
  },
  {
    country: 'United States',
    number: '+1 800 247 9297',
    hours: '24/7',
    notes: 'Toll-free number for US customers'
  },
  {
    country: 'Canada',
    number: '+1 800 247 9297',
    hours: '24/7',
    notes: 'Toll-free number for Canadian customers'
  },
  {
    country: 'Australia',
    number: '+61 1300 767 177',
    hours: '24/7',
    notes: 'Local rate applies'
  },
  {
    country: 'India',
    number: '+91 124 4149 100',
    hours: '24/7',
    notes: 'Standard charges apply'
  }
];

const Support = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Support Numbers</h1>
        <p className="text-xl text-gray-600">Find the right contact number for your region</p>
      </div>

      <div className="grid gap-6">
        {supportNumbers.map((item, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start">
              <Phone className="h-6 w-6 text-blue-600 mr-4 mt-1" />
              <div className="flex-grow">
                <h2 className="text-xl font-semibold text-gray-900">{item.country}</h2>
                <div className="mt-2 grid sm:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Phone Number</p>
                    <p className="font-medium text-blue-600">{item.number}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Hours</p>
                    <p className="font-medium">{item.hours}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Additional Information</p>
                    <p className="font-medium">{item.notes}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-blue-50 rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Important Notice</h2>
        <p className="text-gray-700">
          Call charges may vary depending on your phone provider and whether you're calling from a landline or mobile phone. 
          Some numbers may not be accessible from certain countries.
        </p>
      </div>
    </div>
  );
};

export default Support;